from equation_objects import LorenzSystemEquations, DerivEquation
from forcing import ConstantForcing, SinForcing
from eulers_solver import eulers_method_sys
from visualizations import animate_circle

# Create system
size = 25
force = ConstantForcing(4)
system = LorenzSystemEquations(size, force)

# Solve system
dt = 0.01
final_time = 20
results = eulers_method_sys(system, dt, final_time)

# Animate results
animate_circle(results)