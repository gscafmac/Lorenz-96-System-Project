import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

def animate_circle(data_arr):
    num_sys, num_steps = data_arr.shape

    fig, ax = plt.subplots(figsize=(6,6))
    ax.set_xlim(-1.53, 1.53)
    ax.set_ylim(-1.53, 1.53)
    ax.axis('off')

    # each angle for each circle
    angles = np.linspace(0, 2*np.pi, num_sys, endpoint=False)
    radius = 1.4
    positions = np.array([radius * np.cos(angles), radius * np.sin(angles)]).T # puts each circle in spot with x and y value

    # create circles
    scat = ax.scatter(positions[:,0], positions[:,1], s=500, c=data_arr[:,0], cmap='viridis')

    # function to update called for each animation frame
    def update(frame):
        scat.set_array(data_arr[:, frame])
        scat.set_clim(np.min(data_arr), np.max(data_arr)) # normalize color
        return [scat]

    # actually does the animating
    anim = FuncAnimation(fig, update, frames=num_steps, interval=10, blit=True)
    plt.show()