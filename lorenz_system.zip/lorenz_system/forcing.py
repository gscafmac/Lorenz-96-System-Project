import math

class ConstantForcing:
    def __init__(self, c):
        self.c = c

    def __call__(self, t):
        return self.c
    

class SinForcing:
    def __init__(self, a, b):
        self.a = a
        self.b = b

    def __call__(self, t):
        return self.a * math.sin(self.b * t)